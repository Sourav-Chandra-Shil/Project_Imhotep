# Shared QSS styles (optional)
